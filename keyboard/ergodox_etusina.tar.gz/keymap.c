#include QMK_KEYBOARD_H
#include "version.h"
#include "keymap_german.h"
#include "keymap_nordic.h"
#include "keymap_french.h"

#define KC_MAC_UNDO LGUI(KC_Z)
#define KC_MAC_CUT LGUI(KC_X)
#define KC_MAC_COPY LGUI(KC_C)
#define KC_MAC_PASTE LGUI(KC_V)
#define KC_PC_UNDO LCTL(KC_Z)
#define KC_PC_CUT LCTL(KC_X)
#define KC_PC_COPY LCTL(KC_C)
#define KC_PC_PASTE LCTL(KC_V)
#define ES_LESS_MAC KC_GRAVE
#define ES_GRTR_MAC LSFT(KC_GRAVE)
#define ES_BSLS_MAC ALGR(KC_6)
#define NO_PIPE_ALT KC_GRAVE
#define NO_BSLS_ALT KC_EQUAL
#define LSA_T(kc) MT(MOD_LSFT | MOD_LALT, kc)
#define BP_NDSH_MAC ALGR(KC_8)
#define SE_SECT_MAC ALGR(KC_6)

enum custom_keycodes {
  RGB_SLD = EZ_SAFE_RANGE,
};


const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [0] = LAYOUT_ergodox_pretty(
    KC_GRAVE,       KC_1,           KC_2,           KC_3,           KC_4,           KC_5,           KC_INSERT,                                      KC_DELETE,      KC_MEDIA_PLAY_PAUSE,KC_6,           KC_7,           KC_8,           KC_9,           KC_0,
    KC_LBRACKET,    KC_Q,           KC_W,           KC_E,           KC_R,           KC_T,           KC_TAB,                                         KC_BSPACE,      KC_Y,           KC_U,           KC_I,           KC_O,           KC_P,           KC_MINUS,
    KC_RBRACKET,    KC_A,           KC_S,           KC_D,           KC_F,           KC_G,                                                                           KC_H,           KC_J,           KC_K,           KC_L,           KC_SCOLON,      KC_EQUAL,
    KC_QUOTE,       KC_Z,           KC_X,           KC_C,           KC_V,           KC_B,           LCTL(KC_PGUP),                                  LCTL(KC_PGDOWN),KC_N,           KC_M,           KC_COMMA,       KC_DOT,         KC_SLASH,       KC_BSLASH,
    KC_PSCREEN,     KC_AUDIO_VOL_UP,KC_AUDIO_VOL_DOWN,KC_UP,          KC_DOWN,                                                                                                        KC_LEFT,        KC_RIGHT,       KC_F11,         KC_F13,         KC_F14,
                                                                                                    KC_PGUP,        KC_PGDOWN,      KC_HOME,        KC_END,
                                                                                                                    KC_CAPSLOCK,    TO(2),
                                                                                    KC_NONUS_BSLASH,KC_ESCAPE,      KC_NUMLOCK,     TO(1),          KC_ENTER,       KC_SPACE
  ),
  [1] = LAYOUT_ergodox_pretty(
    KC_F5,          KC_F6,          MT(MOD_LCTL, KC_F7),MT(MOD_LALT, KC_F8),MT(MOD_LSFT, KC_F9),KC_F10,         LGUI(KC_PGUP),                                  LGUI(KC_HOME),  LGUI(KC_H),     MT(MOD_LSFT, KC_F12),MT(MOD_LALT, KC_F1),MT(MOD_LCTL, KC_F2),KC_F3,          KC_F4,
    LGUI(KC_P),     LGUI(KC_U),     LGUI(KC_O),     KC_MS_UP,       LGUI(KC_J),     LGUI(KC_L),     LGUI(KC_PGDOWN),                                LGUI(KC_END),   LCTL(KC_J),     LCTL(KC_SCOLON),KC_MS_WH_UP,    LGUI(KC_I),     LGUI(KC_K),     LCTL(LSFT(KC_J)),
    LGUI(KC_SCOLON),KC_DELETE,      KC_MS_LEFT,     KC_MS_DOWN,     KC_MS_RIGHT,    LCTL(KC_INSERT),                                                                LSFT(KC_INSERT),KC_MS_WH_LEFT,  KC_MS_WH_DOWN,  KC_MS_WH_RIGHT, LGUI(KC_M),     LGUI(KC_COMMA),
    LALT(KC_HOME),  LCTL(KC_Z),     LCTL(KC_X),     LALT(KC_RIGHT), LALT(KC_LEFT),  LCTL(KC_S),     LCTL(KC_PGUP),                                  LCTL(KC_PGDOWN),LCTL(KC_SLASH), KC_MS_BTN1,     KC_MS_BTN3,     KC_MS_BTN2,     LGUI(KC_DOT),   LGUI(KC_SLASH),
    KC_PSCREEN,     KC_AUDIO_VOL_UP,KC_AUDIO_VOL_DOWN,KC_UP,          KC_DOWN,                                                                                                        KC_LEFT,        KC_RIGHT,       KC_F11,         KC_F13,         KC_F14,
                                                                                                    KC_PGUP,        KC_PGDOWN,      KC_HOME,        KC_END,
                                                                                                                    MT(MOD_LSFT, KC_TAB),TO(4),
                                                                                    KC_NONUS_BSLASH,MT(MOD_LGUI, KC_ESCAPE),MT(MOD_LALT, KC_NUMLOCK),TO(2),          MT(MOD_LCTL, KC_ENTER),KC_SPACE
  ),
  [2] = LAYOUT_ergodox_pretty(
    KC_GRAVE,       KC_1,           MT(MOD_RCTL, KC_2),MT(MOD_RALT, KC_3),MT(MOD_RSFT, KC_4),KC_5,           KC_INSERT,                                      KC_DELETE,      KC_MEDIA_PLAY_PAUSE,MT(MOD_LSFT, KC_6),MT(MOD_RALT, KC_7),MT(MOD_RCTL, KC_8),KC_9,           KC_0,
    KC_LBRACKET,    KC_Q,           KC_W,           KC_E,           KC_R,           KC_T,           KC_TAB,                                         KC_BSPACE,      KC_Y,           KC_U,           KC_I,           KC_O,           KC_P,           KC_MINUS,
    KC_RBRACKET,    KC_A,           KC_S,           KC_D,           KC_F,           KC_G,                                                                           KC_H,           KC_J,           KC_K,           KC_L,           KC_SCOLON,      KC_EQUAL,
    MT(MOD_LCTL, KC_QUOTE),KC_Z,           MT(MOD_RCTL, KC_X),MT(MOD_RALT, KC_C),MT(MOD_RSFT, KC_V),KC_B,           LCTL(KC_PGUP),                                  LCTL(KC_PGDOWN),KC_N,           MT(MOD_LSFT, KC_M),MT(MOD_RALT, KC_COMMA),MT(MOD_RCTL, KC_DOT),KC_SLASH,       MT(MOD_LGUI, KC_BSLASH),
    KC_PSCREEN,     KC_AUDIO_VOL_UP,KC_AUDIO_VOL_DOWN,KC_UP,          KC_DOWN,                                                                                                        KC_LEFT,        KC_RIGHT,       KC_F11,         KC_F13,         KC_F14,
                                                                                                    KC_PGUP,        KC_PGDOWN,      KC_HOME,        KC_END,
                                                                                                                    MT(MOD_RGUI, KC_CAPSLOCK),TO(0),
                                                                                    KC_NONUS_BSLASH,MT(MOD_LGUI, KC_ESCAPE),MT(MOD_LALT, KC_NUMLOCK),TO(1),          MT(MOD_LCTL, KC_ENTER),KC_SPACE
  ),
  [3] = LAYOUT_ergodox_pretty(
    KC_0,           KC_8,           MT(MOD_LCTL, KC_9),MT(MOD_LALT, KC_6),MT(MOD_LSFT, KC_7),KC_5,           KC_QUOTE,                                       LGUI(KC_M),     LGUI(KC_J),     LGUI(KC_L),     LGUI(KC_U),     LGUI(KC_O),     LCTL(KC_J),     LCTL(LSFT(KC_J)),
    KC_KP_9,        KC_KP_8,        KC_KP_7,        KC_KP_6,        KC_KP_5,        KC_NO,          KC_AUDIO_VOL_UP,                                LGUI(KC_PGDOWN),LCTL(KC_INSERT),LSFT(KC_INSERT),KC_MS_UP,       LCTL(KC_SCOLON),LCTL(KC_SLASH), LGUI(KC_H),
    KC_KP_4,        KC_KP_3,        KC_KP_2,        KC_KP_1,        KC_KP_0,        LCTL(KC_Z),                                                                     KC_MS_WH_UP,    KC_MS_LEFT,     KC_MS_DOWN,     KC_MS_RIGHT,    KC_DELETE,      LGUI(KC_I),
    KC_GRAVE,       KC_1,           KC_2,           KC_3,           KC_4,           LCTL(KC_X),     KC_AUDIO_VOL_DOWN,                                KC_TAB,         KC_MS_WH_DOWN,  LALT(KC_LEFT),  LALT(KC_RIGHT), KC_MS_WH_LEFT,  KC_MS_WH_RIGHT, LGUI(KC_K),
    KC_F13,         KC_UP,          KC_DOWN,        KC_LEFT,        KC_RIGHT,                                                                                                       KC_MS_BTN3,     LALT(KC_HOME),  KC_UP,          KC_DOWN,        KC_PSCREEN,
                                                                                                    MT(MOD_LCTL, KC_ENTER),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LCTL, KC_ENTER),
                                                                                                                    TO(1),          MT(MOD_LSFT, KC_NUMLOCK),
                                                                                    MT(MOD_LSFT, KC_SPACE),MT(MOD_LGUI, KC_NONUS_BSLASH),TO(5),          TO(4),          KC_MS_BTN2,     KC_MS_BTN1
  ),
  [4] = LAYOUT_ergodox_pretty(
    KC_G,           KC_Q,           MT(MOD_LCTL, KC_E),MT(MOD_LALT, KC_I),MT(MOD_LSFT, KC_P),KC_H,           KC_BSLASH,                                      KC_QUOTE,       KC_5,           MT(MOD_LSFT, KC_6),MT(MOD_LALT, KC_7),MT(MOD_LCTL, KC_8),KC_9,           KC_0,
    MT(MOD_LALT | MOD_LCTL, KC_PGUP),KC_A,           KC_D,           KC_K,           KC_SCOLON,      TO(6),          LCTL(KC_PGUP),                                  KC_AUDIO_VOL_UP,KC_NO,          KC_KP_5,        KC_KP_6,        KC_KP_7,        KC_KP_8,        KC_KP_9,
    MT(MOD_LSFT | MOD_LCTL, KC_PGDOWN),KC_S,           KC_F,           KC_J,           KC_L,           MT(MOD_RALT, KC_NUMLOCK),                                                                LCTL(KC_Z),     KC_KP_0,        KC_KP_1,        KC_KP_2,        KC_KP_3,        KC_KP_4,
    LALT(KC_LSHIFT),KC_W,           KC_R,           KC_U,           KC_O,           MT(MOD_RCTL, KC_BSPACE),LCTL(KC_PGDOWN),                                KC_AUDIO_VOL_DOWN,LCTL(KC_X),     KC_4,           KC_3,           KC_2,           KC_1,           KC_GRAVE,
    KC_F11,         KC_C,           KC_V,           KC_M,           KC_COMMA,                                                                                                       KC_LEFT,        KC_RIGHT,       KC_UP,          KC_DOWN,        KC_F13,
                                                                                                    MT(MOD_LCTL, KC_ENTER),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LCTL, KC_ENTER),
                                                                                                                    OSL(6),         TO(1),
                                                                                    MT(MOD_LSFT, KC_SPACE),MT(MOD_LGUI, KC_NONUS_BSLASH),TO(3),          TO(5),          MT(MOD_LGUI, KC_NONUS_BSLASH),MT(MOD_LSFT, KC_SPACE)
  ),
  [5] = LAYOUT_ergodox_pretty(
    LCTL(LSFT(KC_J)),LCTL(KC_J),     LGUI(KC_U),     LGUI(KC_O),     LGUI(KC_J),     LGUI(KC_L),     LGUI(KC_M),                                     KC_BSLASH,      KC_H,           MT(MOD_LSFT, KC_P),MT(MOD_LALT, KC_I),MT(MOD_LCTL, KC_E),KC_Q,           KC_G,
    LGUI(KC_H),     LCTL(KC_SLASH), LCTL(KC_SCOLON),KC_MS_UP,       LSFT(KC_INSERT),LCTL(KC_INSERT),LGUI(KC_PGDOWN),                                LCTL(KC_PGUP),  TO(7),          KC_SCOLON,      KC_K,           KC_D,           KC_A,           MT(MOD_LALT | MOD_LCTL, KC_PGUP),
    LGUI(KC_I),     KC_DELETE,      KC_MS_LEFT,     KC_MS_DOWN,     KC_MS_RIGHT,    KC_MS_WH_UP,                                                                    MT(MOD_RALT, KC_NUMLOCK),KC_J,           KC_L,           KC_S,           KC_F,           MT(MOD_LSFT | MOD_LCTL, KC_PGDOWN),
    LGUI(KC_K),     KC_MS_WH_LEFT,  KC_MS_WH_RIGHT, LALT(KC_RIGHT), LALT(KC_LEFT),  KC_MS_WH_DOWN,  KC_TAB,                                         LCTL(KC_PGDOWN),MT(MOD_RCTL, KC_BSPACE),KC_U,           KC_O,           KC_W,           KC_R,           LALT(KC_LSHIFT),
    KC_PSCREEN,     KC_UP,          KC_DOWN,        LALT(KC_HOME),  KC_MS_BTN3,                                                                                                     KC_M,           KC_COMMA,       KC_C,           KC_V,           KC_F11,
                                                                                                    MT(MOD_LCTL, KC_ENTER),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LCTL, KC_ENTER),
                                                                                                                    MT(MOD_LSFT, KC_NUMLOCK),OSL(7),
                                                                                    KC_MS_BTN1,     KC_MS_BTN2,     TO(4),          TO(3),          MT(MOD_LGUI, KC_NONUS_BSLASH),MT(MOD_LSFT, KC_SPACE)
  ),
  [6] = LAYOUT_ergodox_pretty(
    KC_F5,          KC_F6,          MT(MOD_LCTL, KC_F7),MT(MOD_LALT, KC_F8),MT(MOD_LSFT, KC_F9),KC_F10,         KC_BSLASH,                                      KC_QUOTE,       KC_5,           MT(MOD_LSFT, KC_6),MT(MOD_LALT, KC_7),MT(MOD_LCTL, KC_8),KC_9,           KC_0,
    MT(MOD_LALT | MOD_LCTL, KC_HOME),KC_F3,          KC_F2,          KC_F1,          KC_F12,         TO(4),          KC_F15,                                         KC_AUDIO_VOL_UP,KC_NO,          KC_KP_5,        KC_KP_6,        KC_KP_7,        KC_KP_8,        KC_KP_9,
    MT(MOD_LSFT | MOD_LCTL, KC_END),KC_F4,          KC_LBRACKET,    KC_MINUS,       KC_MEDIA_PLAY_PAUSE,MT(MOD_RALT, KC_CAPSLOCK),                                                                LCTL(KC_Z),     KC_KP_0,        KC_KP_1,        KC_KP_2,        KC_KP_3,        KC_KP_4,
    LALT(KC_LSHIFT),KC_T,           KC_RBRACKET,    KC_EQUAL,       KC_Y,           MT(MOD_RCTL, KC_DELETE),KC_F16,                                         KC_AUDIO_VOL_DOWN,LCTL(KC_X),     KC_4,           KC_3,           KC_2,           KC_1,           KC_GRAVE,
    KC_F14,         KC_Z,           KC_X,           KC_DOT,         KC_SLASH,                                                                                                       KC_LEFT,        KC_RIGHT,       KC_UP,          KC_DOWN,        KC_F13,
                                                                                                    MT(MOD_LCTL, KC_INSERT),MT(MOD_LALT, KC_NONUS_HASH),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LCTL, KC_ENTER),
                                                                                                                    KC_NO,          TO(1),
                                                                                    MT(MOD_LSFT, KC_N),MT(MOD_LGUI, KC_B),KC_SCROLLLOCK,  TO(5),          MT(MOD_LGUI, KC_NONUS_BSLASH),MT(MOD_LSFT, KC_SPACE)
  ),
  [7] = LAYOUT_ergodox_pretty(
    LCTL(LSFT(KC_J)),LCTL(KC_J),     LGUI(KC_U),     LGUI(KC_O),     LGUI(KC_J),     LGUI(KC_L),     LGUI(KC_M),                                     KC_BSLASH,      KC_F10,         MT(MOD_LSFT, KC_F9),MT(MOD_LALT, KC_F8),MT(MOD_LCTL, KC_F7),KC_F6,          KC_F5,
    LGUI(KC_H),     LCTL(KC_SLASH), LCTL(KC_SCOLON),KC_MS_UP,       LSFT(KC_INSERT),LCTL(KC_INSERT),LGUI(KC_PGDOWN),                                KC_F15,         TO(5),          KC_F12,         KC_F1,          KC_F2,          KC_F3,          MT(MOD_LALT | MOD_LCTL, KC_HOME),
    LGUI(KC_I),     KC_DELETE,      KC_MS_LEFT,     KC_MS_DOWN,     KC_MS_RIGHT,    KC_MS_WH_UP,                                                                    MT(MOD_RALT, KC_CAPSLOCK),KC_MEDIA_PLAY_PAUSE,KC_MINUS,       KC_LBRACKET,    KC_F4,          MT(MOD_LSFT | MOD_LCTL, KC_END),
    LGUI(KC_K),     KC_MS_WH_LEFT,  KC_MS_WH_RIGHT, LALT(KC_RIGHT), LALT(KC_LEFT),  KC_MS_WH_DOWN,  KC_TAB,                                         KC_F16,         MT(MOD_RCTL, KC_DELETE),KC_Y,           KC_EQUAL,       KC_RBRACKET,    KC_T,           LALT(KC_LSHIFT),
    KC_PSCREEN,     KC_UP,          KC_DOWN,        LALT(KC_HOME),  KC_MS_BTN3,                                                                                                     KC_DOT,         KC_SLASH,       KC_Z,           KC_X,           KC_F14,
                                                                                                    MT(MOD_LCTL, KC_ENTER),MT(MOD_LALT, KC_ESCAPE),MT(MOD_LALT, KC_NONUS_HASH),MT(MOD_LCTL, KC_INSERT),
                                                                                                                    MT(MOD_LSFT, KC_NUMLOCK),KC_NO,
                                                                                    KC_MS_BTN1,     KC_MS_BTN2,     TO(4),          KC_SCROLLLOCK,  MT(MOD_LGUI, KC_B),MT(MOD_LSFT, KC_N)
  ),
};


bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  switch (keycode) {
  }
  return true;
}

uint32_t layer_state_set_user(uint32_t state) {
  uint8_t layer = biton32(state);
  ergodox_board_led_off();
  ergodox_right_led_1_off();
  ergodox_right_led_2_off();
  ergodox_right_led_3_off();
  switch (layer) {
    case 0:
      ergodox_right_led_3_on();
      break;
    case 1:
      ergodox_right_led_1_on();
      break;
    case 2:
      // default
      break;
    case 3:
      ergodox_right_led_1_on();
      ergodox_right_led_3_on();
      break;
    case 4:
      ergodox_right_led_2_on();
      ergodox_right_led_3_on();
      break;
    case 5:
      ergodox_right_led_1_on();
      ergodox_right_led_2_on();
      break;
    case 6:
    case 7:
      ergodox_right_led_2_on();
      break;
    default:
      break;
  }
  return state;
};


